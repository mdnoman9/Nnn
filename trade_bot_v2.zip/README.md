# Trade Bot (Binance Testnet, Spot)

## সেটআপ
1. `flutter create --platforms android .` (এই ফোল্ডারে চালান, lib/ ও pubspec.yaml ওভাররাইট হবে না)
2. `flutter pub get`
3. `android/app/src/main/AndroidManifest.xml`-এ `<manifest>`-এর ভেতরে যোগ করুন:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
```
এবং `<application>`-এর ভেতরে:
```xml
<service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
  android:foregroundServiceType="dataSync" android:exported="false"/>
```
4. Testnet key: https://testnet.binance.vision (GitHub দিয়ে লগইন)
5. `flutter run` বা `flutter build apk`

## নিরাপত্তা
- শুধু Testnet URL হার্ডকোড করা আছে
- প্রতিটি কেনার সাথে সার্ভারে OCO (SL+TP)
- নেট/AI ব্যর্থ হলে নতুন ট্রেড হয় না
- দৈনিক লস সীমা ও জরুরি বন্ধ বোতাম
